Content-Type: application/x-www-form-urlencoded
Content-Length: 63

nama=uwuiqioiqoi&ttl=ajsalk&jeniskelamin=kdksk&alamat=JLDJSLFCS